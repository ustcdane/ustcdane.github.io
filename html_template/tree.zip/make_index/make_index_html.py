#!/usr/bin/python
#coding:utf8
'''
#=============================================================================
#     FileName: make_index_html.py
#         Desc: 指定日期范围 制作index.html文件
#       Author: DanielWang
#        Email: daneustc@gmail.com
#     HomePage: http://home.ustc.edu.cn/~danewang/
#      Version: 0.0.1
#   LastChange: 2015-09-25 11:39:46
#      History:
#=============================================================================
'''
import os
import sys
from datetime import datetime, date, timedelta

# 生成日期
def date_range(start, stop, step):
	while start < stop:
		yield start
		start += step

if __name__ == "__main__":
	if len(sys.argv) != 3:
		print "Error, eg:", sys.argv[0], " 20141201 20150901"
		exit(1)
	else: # 获得起始、结束时间
		if len(sys.argv[1]) != 8 or len(sys.argv[1]) != 8:
			print "Error, eg:", sys.argv[0], " 20140101 20150901"
			exit(1)
		start = sys.argv[1]
		end = sys.argv[2]
	start_day = datetime.strptime(start, '%Y%m%d')
	end_day = datetime.strptime(end, '%Y%m%d')
	f_index = open('index_head', 'r')
	f_html = open('index.html', 'w')
	for line in f_index:
		line = line.strip()
		line = line + '\n'
		f_html.write(line)
	f_index.close()
	f_html.write('<ol class="tree">\n')
	f_html.write('<li>\n')
	# 写入年节点的数据
	if start[4:] != '0101':
		line = '<label for="folder1">'+start[:4]+'</label> <input type="checkbox"  id="folder1" checked="checked" />\n'
		f_html.write(line)
		f_html.write('\n<ol>\n')
	# 写入月节点的数据
	if start[6:] != '01':
		f_html.write('\n\t<li>\n')
		line = '\t<label for="subfolder1">' + start[4:6] +'</label> <input type="checkbox" id="subfolder1" />'
		f_html.write(line)
		f_html.write('\n\t<ol>\n')
		f_html.write('\t\t<li class="file">\n')
	# 按日期顺序写入
	for d in date_range(start_day, end_day, timedelta(days=1)):
		day_ = d.strftime("%Y%m%d")
		flag = False
		# 新的一年 
		if day_[4:] == '0101':
			if (d - start_day).days > 1: # 把前一年的尾标签补上
				f_html.write('\t\t</li>')
				f_html.write('\n\t</ol>')
				f_html.write('\n\t</li>\n')
				f_html.write('\n</ol>')
				f_html.write('\n</li>\n')
			f_html.write('\n\n<li>\n')
			line = '<label for="folder1">'+day_[:4]+'</label> <input type="checkbox"  id="folder1" checked="checked" />'
			f_html.write(line)
			f_html.write('\n<ol>\n')
			flag = True #新年的标示
		# 新的一个月
		if day_[6:] == '01':
			if (d - start_day).days > 1 and not flag:# 把前一个月的尾标签数据补上
				f_html.write('\n\t\t</li>\n')
				f_html.write('\n\t</ol>')
				f_html.write('\n</li>\n')
			f_html.write('\n<li>\n')
			line = '\t<label for="subfolder1">' +day_[4:6] +'</label> <input type="checkbox" id="subfolder1" />'
			f_html.write(line)
			f_html.write('\n\t<ol>\n')
			f_html.write('\t\t<li class="file">\n')
		# 写每天的数据
		line = '\t\t\t<a href="/doc/example/'+day_+'/" '+'target="_blank">'+day_[6:]+'</a>\n'
		f_html.write(line)
	# 尾标签
	f_html.write('\n\t\t</li>\n')
	f_html.write('\t</ol>\n')
	f_html.write('</li>\n')

	f_html.write('</ol>\n')
	f_html.write('</li>\n')
	f_html.write('</ol>\n')
	f_html.write("</p>\n<p>&nbsp;</p>\n</body></html>")
	f_html.close()
